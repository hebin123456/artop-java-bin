<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='SDKProfile' timestamp='1576599323616'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/data/jenkins/workspace/artop-4.13.x-e4.13/core/tools/org.artop.releng.builds/product/target/products/org.artop.demonstrator.ide/win32/win32/x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/data/jenkins/workspace/artop-4.13.x-e4.13/core/tools/org.artop.releng.builds/product/target/products/org.artop.demonstrator.ide/win32/win32/x86_64'/>
  </properties>
</profile>
